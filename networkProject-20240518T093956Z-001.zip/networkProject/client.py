import socket
import time


def broadcast(first_name, last_name):
    return f"{first_name}, {last_name}, {time.strftime('%Y-%m-%d %H:%M:%S')}"


def run_client():
    serverName = 'localhost'  # Get the host name or IP address
    serverPort = 8855  # Set the server port to 5566

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    client_socket.bind(('0.0.0.0', 0))

    first_name = input("Enter your first name: ")
    last_name = input("Enter your last name: ")

    while True:
        message = broadcast(first_name, last_name)
        client_socket.sendto(message.encode(), (serverName, serverPort))
        time.sleep(2)


if __name__ == '__main__':
    run_client()
