from socket import *

serverPort = 9977
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(("", serverPort))
serverSocket.listen(1)
print("The web server is ready to receive")
while True:

    connectionSocket, addr = serverSocket.accept()
    sentence = connectionSocket.recv(1024).decode()
    print(addr)
    print(sentence)
    ip = addr[0]
    port = addr[1]
    object = sentence.split()[1]
    print(f"The HTTP request is: {object}")

    if (object == '/' or object == '/index.html' or object == '/main_en.html' or object == '/en'):
        connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("\r\n".encode())
        file1 = open("main_en.html", "rb")
        connectionSocket.send(file1.read())

    elif (object == '/ar'):
        connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("\r\n".encode())
        file2 = open("main_ar.html", "rb")
        connectionSocket.send(file2.read())

    elif (object.endswith('.html')):

        connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("\r\n".encode())
        file3 = open("pic.html", "rb")
        connectionSocket.send(file3.read())

    elif (object.endswith('.css')):

        connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
        connectionSocket.send("Content-Type: text/css \r\n".encode())
        connectionSocket.send("\r\n".encode())
        file4 = open("styles.css", "rb")
        connectionSocket.send(file4.read())


    elif (object.endswith('.png')):

        connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
        connectionSocket.send("Content-Type: image/png \r\n".encode())
        connectionSocket.send("\r\n".encode())
        file5 = open("img2.png", "rb")
        connectionSocket.send(file5.read())

    elif (object.endswith('.jpg')):

        connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
        connectionSocket.send("Content-Type: image/jpeg \r\n".encode())
        connectionSocket.send("\r\n".encode())
        file6 = open("img1.jpg", "rb")
        connectionSocket.send(file6.read())

    elif (object == '/yt'):

        connectionSocket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("Location: https://www.youtube.com/ \r\n".encode())
        connectionSocket.send("\r\n".encode())

    elif (object == '/so'):

        connectionSocket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("Location: https://stackoverflow.com \r\n".encode())
        connectionSocket.send("\r\n".encode())

    elif (object == '/rt'):
        connectionSocket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("Location: https://ritaj.birzeit.edu/register/ \r\n".encode())
        connectionSocket.send("\r\n".encode())


    else:
        connectionSocket.send("HTTP/1.1 404 Not Found \r\n".encode())
        connectionSocket.send("Content-Type: text/html \r\n".encode())
        connectionSocket.send("\r\n".encode())
        notFoundHtmlString = "test.html"

        notFoundHtmlBytes = bytes(notFoundHtmlString, "UTF-8")
        connectionSocket.send(notFoundHtmlBytes)

    connectionSocket.close()
