import socket


def get_client_key(address, port):
    return address[0] + ':' + str(port)


def parse_message(message):
    parts = message.split(',')
    if len(parts) == 3:
        return parts[0].strip(), parts[1].strip(), parts[2].strip()
    return None


def run_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(('0.0.0.0', 8855))

    clients = {}

    while True:
        data, address = server_socket.recvfrom(1024)
        client_key = get_client_key(address[0], address[1])
        message = data.decode()

        if client_key not in clients:
            clients[client_key] = {'first_name': '', 'last_name': '', 'last_time': ''}

        parsed_message = parse_message(message)

        if parsed_message:
            clients[client_key]['first_name'], clients[client_key]['last_name'], clients[client_key][
                'last_time'] = parsed_message

        print(
            f"Received message from {clients[client_key]['first_name']} {clients[client_key]['last_name']} at {clients[client_key]['last_time']}")

        for client in clients.values():
            print(f"Received message from {client['first_name']} {client['last_name']} at {client['last_time']}")


if __name__ == '__main__':
    run_server()
